import React from 'react';
import {
  StyleSheet,
  Text,
  View,
  Image,
  TouchableOpacity,
  ImageBackground, // <--- Import
} from 'react-native';
import { Card } from 'react-native-paper';
import Constants from 'expo-constants';
import { useFonts } from 'expo-font';
import FaceView from './components/FaceView';

export default function App() {

  const handleButtonPress = () => {
    alert('London is Red !!!');
  };

  return (
    // ใช้ ImageBackground ครอบเนื้อหาทั้งหมด
    <ImageBackground
      source={require('./assets/arsenal.jpg')} // เปลี่ยนเป็นรูปตามต้องการ
      style={styles.bgImage}
      resizeMode="cover" 
    >
      {/* ด้านในคง View container เดิม */}
      <View style={styles.container}>

        {/* Title */}
        <Text style={styles.paragraph}>Work 5: Prommin</Text>

        {/* Image */}
        <Image
          source={require('./assets/arsenal-logo.png')}
          style={styles.image}
        />
        
        {/* Card + FaceView */}
        <Card style={styles.card}>
          <View style={styles.faceViewContainer}>
            <FaceView />
          </View>
        </Card>

        {/* Custom Button */}
        <TouchableOpacity style={styles.button} onPress={handleButtonPress}>
          <Text style={styles.buttonText}>Click Me !</Text>
        </TouchableOpacity>

        {/* Footer text */}
        <Text style={styles.paragraph}>
          653380140-6 นายพรหมมินทร์ อินกันหา
        </Text>
      </View>
    </ImageBackground>
  );
}

const styles = StyleSheet.create({
  bgImage: {
    flex: 1,           // ให้รูปภาพเต็มจอ
    width: '100%',     // ป้องกันภาพเหลื่อม
    height: '100%',    // ป้องกันภาพเหลื่อม
  },
  container: {
    flex: 1,
    paddingTop: Constants.statusBarHeight,
    // ลบ backgroundColor ออก หรือใส่สีที่มีความโปร่งใสได้
    backgroundColor: 'rgba(236, 240, 241, 0.5)', 
    paddingHorizontal: 16,
    paddingBottom: 16,
    alignItems: 'center',
    justifyContent: 'center',
  },
  paragraph: {
    marginTop: 24,
    fontSize: 26,
    fontWeight: 'bold',
    textAlign: 'center',
    fontFamily: 'chakapetch',
    color: '#333',
  },
  image: {
    width: 150,
    height: 90,
    marginVertical: 10,
  },
  card: {
    width: '90%',
    borderRadius: 10,
    elevation: 3,
    marginVertical: 10,
    backgroundColor: '#fff',
  },
  faceViewContainer: {
    height: 400,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#001111',
    borderRadius: 8,
    margin: 10,
  },
  button: {
    backgroundColor: '#fd464a',
    paddingVertical: 14,
    paddingHorizontal: 40,
    borderRadius: 25,
    marginTop: 15,
    elevation: 3,
  },
  buttonText: {
    color: '#fff',
    fontSize: 18,
    fontFamily: 'chakapetch',
    fontWeight: '600',
  },
});
