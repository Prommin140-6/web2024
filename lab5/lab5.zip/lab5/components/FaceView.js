import React, { useState } from 'react';
import { Text, View, StyleSheet, Image, Button } from 'react-native';
import { CameraView, useCameraPermissions } from 'expo-camera';

export default function FaceView() {
  const [facing, setFacing] = useState('front');
  const [flash, setFlash] = useState('on');
  const [zoom, setZoom] = useState(0.5);
  const [mirror, setMirror] = useState(true);

  const [permission, requestPermission] = useCameraPermissions();

  if (!permission) {
    return (
      <View style={styles.center}>
        <Text style={styles.textError}>ไม่มีกล้อง</Text>
      </View>
    );
  }

  if (!permission.granted) {
    return (
      <View style={styles.center}>
        <Text style={styles.textError}>
          We need your permission to show the camera
        </Text>
        <Button onPress={requestPermission} title="grant permission" />
      </View>
    );
  }

  const b1 = require('../assets/b2.png');

  const toggleFace = () => {
    setFacing((current) => (current === 'back' ? 'front' : 'back'));
  };

  const toggleFlash = () => {
    setFlash((current) => (current === 'on' ? 'off' : 'on'));
  };

  return (
    <View style={styles.container}>
      {/* ตัวอย่างการแสดงรูปเล็ก ๆ ด้านบน */}
      <Image source={b1} style={{ width: 0, height: 0 }} />

      {/* กล้อง */}
      <View style={styles.cameraContainer}>
        <CameraView
          style={styles.camera}
          facing={facing}
          zoom={zoom}
          flash={flash}
          mirror={mirror}
        >
          <View style={styles.overlay}>
            <View style={styles.row}>
              <Button title="สลับกล้อง" onPress={toggleFace} />

              {/* ใส่ style ใน Text */}
              <Text style={styles.textCenter}>Zoom</Text>
              
              <Button title="x0" onPress={() => setZoom(0.0)} />
              <Button title="x0.1" onPress={() => setZoom(0.1)} />
              <Button title="x0.5" onPress={() => setZoom(0.5)} />

              <Text style={styles.textCenter}>{facing}</Text>
            </View>
          </View>
        </CameraView>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  center: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  container: {
    width: '100%',
    alignItems: 'center',
    padding: 10,
  },
  cameraContainer: {
    width: '100%',
    aspectRatio: 4 / 5,
    borderRadius: 10,
    backgroundColor: '#000',
    overflow: 'hidden',
  },
  camera: {
    flex: 1,
  },
  // ส่วน overlay หากอยากให้ปุ่ม/ข้อความลอยด้านบนกล้อง
  overlay: {
    flex: 1,
    justifyContent: 'flex-end', // ดันให้ row อยู่ด้านล่าง
  },
  row: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    // จัดให้อยู่กึ่งกลางทั้งแนวตั้ง/แนวนอน
    justifyContent: 'center',
    alignItems: 'center',

    // พื้นหลังโปร่งใสเล็กน้อย
    backgroundColor: 'rgba(0,0,0,0.3)',
    padding: 6,
    marginBottom: 10,
  },
  textCenter: {
    textAlign: 'center',
    marginHorizontal: 8,
    fontSize: 16,
    fontWeight: 'bold',
    color: '#fff',
  },
  textError: {
    color: 'red',
    marginVertical: 8,
    textAlign: 'center',
  },
});
